<link rel="stylesheet" href="<?= _backEnd() ?>highlight/styles/<?= $slug ?>">
<script src="<?= _backEnd() ?>highlight/highlight.min.js"></script>
<script>
	hljs.highlightAll();
</script>


<pre>
	<code class="language">
&lt;!DOCTYPE html&gt;
&lt;html lang=&quot;en&quot;&gt;
&lt;head&gt;
	&lt;meta charset=&quot;UTF-8&quot;&gt;
	&lt;meta http-equiv=&quot;X-UA-Compatible&quot; content=&quot;IE=edge&quot;&gt;
	&lt;meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1.0&quot;&gt;
	&lt;title&gt;Hello World&lt;/title&gt;
&lt;/head&gt;
&lt;body&gt;

	&lt;h1&gt;Hello World&lt;/h1&gt;

&lt;/body&gt;
&lt;/html&gt;
	</code>
</pre>
