<?php
$sk["DB_HOST"] = "localhost";
$sk["DB_USER"] = "root";
$sk["DB_PASS"] = "root";
$sk["DB_NAME"] = "velixsnime";
        